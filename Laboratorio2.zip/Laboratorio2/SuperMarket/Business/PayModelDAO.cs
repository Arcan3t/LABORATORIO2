﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SuperMarket.Model;

namespace SuperMarket.Business
{
    internal class PayModelDAO
    {
        private readonly Dictionary<int, PayMode> PayModelList;
        private static int payModeSecuencial;

        public PayModelDAO()
        {
            PayModelList = new Dictionary<int, PayMode>();
            payModeSecuencial = 0;
        }

        public bool AddPayMode(PayMode payMode)
        {
            try
            {
                payMode.Id = ++payModeSecuencial;
                PayModelList.Add((int)payMode.Id, payMode);
            }
            catch
            {
                return false;
            }
            return true;
        }

        public bool RemovePayMode(int id)
        {
            bool idExist = PayModelList.ContainsKey(id);
            if (idExist)
            {
                PayModelList.Remove(id);
                return true;
            }
            return false;
        }

        public PayMode GetPayMode(int id)
        {
            bool idExist = PayModelList.ContainsKey(id);
            if (idExist)
            {
                PayMode payMode = PayModelList[id];
                return payMode;
            }
            return null;
        }

        public bool UpdatePayMode(int id, PayMode payMode)
        {
            bool idExist = PayModelList.ContainsKey(id);
            if (idExist)
            {
                try
                {
                    PayModelList[id] = payMode;
                    return true;
                }
                catch (KeyNotFoundException)
                {
                    return false;
                }
            }
            return false;
        }

        public Dictionary<int, PayMode> GetPayModelList()
        {
            return PayModelList;
        }
    }
}
