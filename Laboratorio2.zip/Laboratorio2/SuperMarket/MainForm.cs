using SuperMarket.Business;
using SuperMarket.View;

namespace SuperMarket
{
    public partial class MainForm : Form
    {
        internal PayModelDAO payModelDAO;

        public MainForm()
        {
            payModelDAO = new PayModelDAO();
            InitializeComponent();
            payModelDAO.AddPayMode(new Model.PayMode(null, "Cash"));
        }

        private void ExitMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AboutMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("SuperMarket V0.1", "About us");
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void PayModeMenuItem_Click(object sender, EventArgs e)
        {
            PayModeForm formPayMode = new PayModeForm(ref payModelDAO);
            formPayMode.MdiParent = this;
            formPayMode.Show();
        }
    }
}