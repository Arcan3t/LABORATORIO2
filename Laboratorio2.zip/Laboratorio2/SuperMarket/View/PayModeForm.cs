﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SuperMarket.Business;
using SuperMarket.Model;
using SuperMarket.Properties;


namespace SuperMarket.View
{
    public partial class PayModeForm : Form
    {
        private readonly PayModelDAO payModelDAO;
        private bool EditMode;
        private bool IsNew;

        internal PayModeForm(ref PayModelDAO payModelDAO)
        {
            InitializeComponent();
            this.payModelDAO = payModelDAO;
            LoadPayModelList();
            EditMode = false;
            IsNew = false;
        }

        private void LoadPayModelList()
        {
            DgPayMode.Rows.Clear();
            foreach (KeyValuePair<int, PayMode> payModeKV in this.payModelDAO.GetPayModelList())
            {
                DgPayMode.Rows.Add(payModeKV.Value.Id, payModeKV.Value.Name);
            }
        }

        public PayModeForm()
        {
            InitializeComponent();
        }        

        private void DgPayMode_Click(object sender, EventArgs e)
        {
            TxtId.Text = DgPayMode.CurrentRow.Cells[0].Value.ToString();
            TxtName.Text = DgPayMode.CurrentRow.Cells[1].Value.ToString();
        }

        private void BtnNew_Click(object sender, EventArgs e)
        {
            if (EditMode == false)
            {
                EditMode = true;
                IsNew = true;
            }
            else
            {
                if (SavePayMode() == false)
                {
                    return;
                }
                IsNew = false;
                EditMode = false;
            }
            TxtId.Text = "";
            TxtName.Text = "";
            ActivateControls(EditMode);
        }

        private void ActivateControls(bool state)
        {
            if (EditMode == true)
            {
                BtnNew.Text = "Save";
                BtnNew.Image = Resources.save;
                BtnEdit.Text = "Cancel";
                BtnEdit.Image = Resources.cancel;
            }
            else
            {
                BtnNew.Text = "New";
                BtnNew.Image = Resources._new;
                BtnEdit.Text = "Edit";
                BtnEdit.Image = Resources.edit;
            }
            TxtName.Enabled = state;
            DgPayMode.Enabled = !state;
            BtnDelete.Enabled = !state;
            BtnClose.Enabled = !state;
            TxtName.Focus();
        }

        private bool SavePayMode()
        {
            if (!IsNameFilled())
            {
                return false;
            }
            if (IsNew == true)
            {
                PayMode payMode = new(null, TxtName.Text);
                if (payModelDAO.AddPayMode(payMode) == false)
                {
                    MessageBox.Show("Error to save", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                MessageBox.Show("Pay mode save susessfuly", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadPayModelList();
            }
            else
            {
                int id = Int32.Parse(TxtId.Text);
                PayMode payMode = payModelDAO.GetPayMode(id);
                if (payMode != null)
                {
                    if (!IsNameFilled())
                    {
                        return false;
                    }
                    payMode.Name = TxtName.Text;
                    payModelDAO.UpdatePayMode(id, payMode);
                    LoadPayModelList();
                    return true;
                }
                return false;
            }
            return true;
        }        

        private bool IsNameFilled()
        {
            if ((TxtName.Text).Trim().Length == 0)
            {
                MessageBox.Show("The pay mode is required", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);
                TxtName.Focus();
                return false;
            }
            return true;
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            if (EditMode == true)
            {
                EditMode = false;
            }
            else
            {
                if (TxtName.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Select one register of the list", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                EditMode = true;
                IsNew = false;
            }
            ActivateControls(EditMode);
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (TxtName.Text.Trim().Length == 0)
            {
                MessageBox.Show("Select one register of the list", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            else
            {
                if (MessageBox.Show("Are you sure for Drop this element?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int id = Int32.Parse(TxtId.Text);
                    PayMode payMode = new(id, TxtName.Text);
                    payModelDAO.RemovePayMode(id);
                    MessageBox.Show("Pay mode remove susessfuly", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadPayModelList();
                }
                else
                {
                    MessageBox.Show("Process canceled", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }                      
            
        }
    }
}
